import React, { useEffect, useRef, useState } from 'react';
import { Mic, MicOff, X, Activity, Volume2 } from 'lucide-react';
import { getClient } from '../services/geminiService';
import { AppSettings, ConnectionState } from '../types';
import { createPcmBlob, decodeAudioData, base64ToUint8Array } from '../utils/audioUtils';
import { LiveServerMessage, Modality } from '@google/genai';

interface LiveInterfaceProps {
  isOpen: boolean;
  onClose: () => void;
  settings: AppSettings;
}

export const LiveInterface: React.FC<LiveInterfaceProps> = ({ isOpen, onClose, settings }) => {
  const [status, setStatus] = useState<ConnectionState>(ConnectionState.DISCONNECTED);
  const [isMuted, setIsMuted] = useState(false);
  const [volume, setVolume] = useState(0);
  
  // Audio Refs
  const audioContextRef = useRef<AudioContext | null>(null);
  const inputContextRef = useRef<AudioContext | null>(null);
  const nextStartTimeRef = useRef<number>(0);
  const streamRef = useRef<MediaStream | null>(null);
  const sourcesRef = useRef<Set<AudioBufferSourceNode>>(new Set());
  const sessionRef = useRef<any>(null); // Keep track of the session promise/object

  // Visualizer Canvas
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const animationFrameRef = useRef<number>(0);

  useEffect(() => {
    if (isOpen) {
      startSession();
    } else {
      stopSession();
    }
    return () => stopSession();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isOpen]);

  useEffect(() => {
    if (status === ConnectionState.CONNECTED) {
      drawVisualizer();
    } else {
      cancelAnimationFrame(animationFrameRef.current);
    }
  }, [status, volume]);

  const startSession = async () => {
    try {
      setStatus(ConnectionState.CONNECTING);
      
      // Initialize Audio Contexts
      const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
      inputContextRef.current = new AudioContextClass({ sampleRate: 16000 });
      audioContextRef.current = new AudioContextClass({ sampleRate: 24000 });
      nextStartTimeRef.current = 0;

      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      streamRef.current = stream;

      const ai = getClient();

      const sessionPromise = ai.live.connect({
        model: 'gemini-2.5-flash-native-audio-preview-09-2025',
        config: {
          responseModalities: [Modality.AUDIO],
          speechConfig: {
            voiceConfig: { prebuiltVoiceConfig: { voiceName: settings.voiceName || 'Zephyr' } },
          },
          systemInstruction: settings.systemInstruction,
        },
        callbacks: {
            onopen: () => {
                console.log("Live Session Opened");
                setStatus(ConnectionState.CONNECTED);

                // Input processing
                if (!inputContextRef.current) return;
                
                const source = inputContextRef.current.createMediaStreamSource(stream);
                const scriptProcessor = inputContextRef.current.createScriptProcessor(4096, 1, 1);
                
                scriptProcessor.onaudioprocess = (e) => {
                    if (isMuted) return; // Don't send if muted
                    
                    const inputData = e.inputBuffer.getChannelData(0);
                    
                    // Calculate volume for visualizer
                    let sum = 0;
                    for(let i=0; i<inputData.length; i++) sum += inputData[i]*inputData[i];
                    setVolume(Math.sqrt(sum/inputData.length) * 10); // Simple RMS

                    const pcmBlob = createPcmBlob(inputData);
                    sessionPromise.then((session: any) => {
                        session.sendRealtimeInput({ media: pcmBlob });
                    });
                };

                source.connect(scriptProcessor);
                scriptProcessor.connect(inputContextRef.current.destination);
            },
            onmessage: async (message: LiveServerMessage) => {
                if (!audioContextRef.current) return;

                // Handle Audio Output
                const base64Audio = message.serverContent?.modelTurn?.parts?.[0]?.inlineData?.data;
                if (base64Audio) {
                    // Simple visualizer bump for output
                    setVolume(0.5); 
                    setTimeout(() => setVolume(0.1), 200);

                    const ctx = audioContextRef.current;
                    nextStartTimeRef.current = Math.max(nextStartTimeRef.current, ctx.currentTime);
                    
                    const audioBuffer = await decodeAudioData(
                        base64ToUint8Array(base64Audio),
                        ctx,
                        24000
                    );
                    
                    const source = ctx.createBufferSource();
                    source.buffer = audioBuffer;
                    source.connect(ctx.destination);
                    
                    source.addEventListener('ended', () => {
                        sourcesRef.current.delete(source);
                    });
                    
                    source.start(nextStartTimeRef.current);
                    nextStartTimeRef.current += audioBuffer.duration;
                    sourcesRef.current.add(source);
                }
                
                const interrupted = message.serverContent?.interrupted;
                if (interrupted) {
                    sourcesRef.current.forEach(s => s.stop());
                    sourcesRef.current.clear();
                    nextStartTimeRef.current = 0;
                }
            },
            onclose: () => {
                console.log("Session Closed");
                setStatus(ConnectionState.DISCONNECTED);
            },
            onerror: (err) => {
                console.error("Session Error", err);
                setStatus(ConnectionState.ERROR);
            }
        }
      });
      
      sessionRef.current = sessionPromise;

    } catch (e) {
      console.error(e);
      setStatus(ConnectionState.ERROR);
    }
  };

  const stopSession = () => {
    if (streamRef.current) {
        streamRef.current.getTracks().forEach(track => track.stop());
    }
    if (inputContextRef.current) inputContextRef.current.close();
    if (audioContextRef.current) audioContextRef.current.close();
    
    // Close live session if possible
    if (sessionRef.current) {
        sessionRef.current.then((session: any) => {
            // Attempt clean close, though library might handle it on page unload
             // session.close() might not exist on the type depending on version, but we try
             try { session.close(); } catch(e) {}
        });
    }
    setStatus(ConnectionState.DISCONNECTED);
  };

  const toggleMute = () => {
    setIsMuted(!isMuted);
  };

  const drawVisualizer = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    canvas.width = canvas.offsetWidth;
    canvas.height = canvas.offsetHeight;
    const centerX = canvas.width / 2;
    const centerY = canvas.height / 2;

    const draw = () => {
      if (!canvas) return;
      ctx.clearRect(0, 0, canvas.width, canvas.height);

      // Dynamic circles based on volume
      const baseRadius = 80;
      const scale = 1 + Math.max(0.1, volume); 
      
      // Outer Glow
      ctx.beginPath();
      ctx.arc(centerX, centerY, baseRadius * scale * 1.2, 0, 2 * Math.PI);
      ctx.fillStyle = 'rgba(99, 102, 241, 0.2)'; // Indigo
      ctx.fill();

      // Middle Ring
      ctx.beginPath();
      ctx.arc(centerX, centerY, baseRadius * scale * 1.1, 0, 2 * Math.PI);
      ctx.strokeStyle = 'rgba(139, 92, 246, 0.5)'; // Violet
      ctx.lineWidth = 4;
      ctx.stroke();

      // Core
      ctx.beginPath();
      ctx.arc(centerX, centerY, baseRadius * scale, 0, 2 * Math.PI);
      ctx.fillStyle = status === ConnectionState.CONNECTED ? '#6366f1' : '#ef4444';
      ctx.fill();

      // Ripple effect
      ctx.beginPath();
      ctx.arc(centerX, centerY, baseRadius * scale * 1.5, 0, 2 * Math.PI);
      ctx.strokeStyle = `rgba(255, 255, 255, ${0.1 * Math.sin(Date.now() / 500)})`;
      ctx.stroke();
      
      animationFrameRef.current = requestAnimationFrame(draw);
    };

    draw();
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-darker flex flex-col items-center justify-center">
      {/* Background Ambience */}
      <div className="absolute inset-0 bg-gradient-to-b from-indigo-900/20 to-slate-950 pointer-events-none" />
      
      {/* Top Bar */}
      <div className="absolute top-0 left-0 right-0 p-6 flex justify-between items-center z-10">
        <div className="flex items-center gap-2 bg-white/5 px-4 py-2 rounded-full border border-white/10">
            <div className={`w-2 h-2 rounded-full ${status === ConnectionState.CONNECTED ? 'bg-green-400 animate-pulse' : 'bg-yellow-400'}`} />
            <span className="text-xs font-medium text-slate-300 uppercase tracking-wider">
              {status === ConnectionState.CONNECTED ? 'Live Connected' : 'Initializing...'}
            </span>
        </div>
        <button onClick={onClose} className="p-3 bg-white/5 rounded-full text-slate-300 hover:bg-red-500/20 hover:text-red-400 transition-all">
          <X size={24} />
        </button>
      </div>

      {/* Main Visualizer */}
      <div className="relative w-full max-w-md aspect-square flex items-center justify-center">
        <canvas ref={canvasRef} className="w-full h-full absolute inset-0" />
        {status === ConnectionState.ERROR && (
            <div className="absolute text-red-400 text-center bg-black/50 p-4 rounded-xl backdrop-blur-md">
                <p className="font-bold">Connection Failed</p>
                <p className="text-sm">Check microphone permissions or API key.</p>
            </div>
        )}
      </div>

      <div className="absolute bottom-12 flex items-center gap-8 z-10">
         <button 
            onClick={toggleMute}
            className={`p-6 rounded-full transition-all transform hover:scale-105 shadow-2xl border-2 ${isMuted ? 'bg-red-500/20 border-red-500 text-red-500' : 'bg-white/10 border-white/20 text-white hover:bg-white/20'}`}
         >
            {isMuted ? <MicOff size={32} /> : <Mic size={32} />}
         </button>
         <div className="text-center text-slate-400 text-sm mt-4">
            {isMuted ? 'Microphone Muted' : 'Listening...'}
         </div>
      </div>
    </div>
  );
};