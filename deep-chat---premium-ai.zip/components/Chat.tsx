import React, { useState, useRef, useEffect } from 'react';
import { Send, Image as ImageIcon, Mic, User as UserIcon, Bot, Loader2, Paperclip, X, Sparkles, Copy, Volume2, RotateCcw, Check, Share2 } from 'lucide-react';
import ReactMarkdown from 'react-markdown';
import { Message, Sender, AppSettings } from '../types';
import { generateTextResponse } from '../services/geminiService';

interface ChatProps {
  settings: AppSettings;
  onStartLive: () => void;
}

export const Chat: React.FC<ChatProps> = ({ settings, onStartLive }) => {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: '1',
      text: `**Welcome to Deep Chat.** \n\nI am your advanced AI assistant. How can I help you today, ${settings.userName}?`,
      sender: Sender.AI,
      timestamp: new Date(),
    }
  ]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [selectedImage, setSelectedImage] = useState<string | null>(null);
  const [speakingId, setSpeakingId] = useState<string | null>(null);
  const [copiedId, setCopiedId] = useState<string | null>(null);
  
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  // Auto-resize textarea
  useEffect(() => {
    if (textareaRef.current) {
      textareaRef.current.style.height = 'auto';
      textareaRef.current.style.height = textareaRef.current.scrollHeight + 'px';
    }
  }, [input]);

  const handleImageSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setSelectedImage(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const sendMessage = async () => {
    if ((!input.trim() && !selectedImage) || isLoading) return;

    const userMsg: Message = {
      id: Date.now().toString(),
      text: input,
      sender: Sender.USER,
      timestamp: new Date(),
      image: selectedImage || undefined
    };

    setMessages(prev => [...prev, userMsg]);
    setInput('');
    setSelectedImage(null);
    if (textareaRef.current) textareaRef.current.style.height = 'auto';
    setIsLoading(true);

    try {
      const responseText = await generateTextResponse(messages, userMsg.text, settings.systemInstruction, userMsg.image);
      
      const aiMsg: Message = {
        id: (Date.now() + 1).toString(),
        text: responseText,
        sender: Sender.AI,
        timestamp: new Date(),
      };
      setMessages(prev => [...prev, aiMsg]);
    } catch (error) {
      const errorMsg: Message = {
        id: (Date.now() + 1).toString(),
        text: "I'm having trouble connecting right now. Please check your connection or API key.",
        sender: Sender.AI,
        timestamp: new Date(),
        isError: true
      };
      setMessages(prev => [...prev, errorMsg]);
    } finally {
      setIsLoading(false);
    }
  };

  const handleCopy = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const handleSpeak = (text: string, id: string) => {
    if (speakingId === id) {
      window.speechSynthesis.cancel();
      setSpeakingId(null);
    } else {
      window.speechSynthesis.cancel();
      const utterance = new SpeechSynthesisUtterance(text);
      // Try to find a good voice
      const voices = window.speechSynthesis.getVoices();
      const preferredVoice = voices.find(v => v.name.includes('Google') && v.lang.includes('en')) || voices[0];
      if (preferredVoice) utterance.voice = preferredVoice;
      
      utterance.onend = () => setSpeakingId(null);
      setSpeakingId(id);
      window.speechSynthesis.speak(utterance);
    }
  };

  return (
    <div className="flex flex-col h-full relative bg-gradient-to-b from-darker to-dark">
      {/* Messages Area */}
      <div className="flex-1 overflow-y-auto p-4 md:p-6 space-y-8 scroll-smooth">
        {messages.map((msg) => (
          <div
            key={msg.id}
            className={`flex ${msg.sender === Sender.USER ? 'justify-end' : 'justify-start'} animate-slide-up group`}
          >
            <div className={`flex max-w-[90%] md:max-w-[80%] gap-4 ${msg.sender === Sender.USER ? 'flex-row-reverse' : 'flex-row'}`}>
              {/* Avatar */}
              <div className={`w-10 h-10 rounded-2xl flex items-center justify-center flex-shrink-0 shadow-lg shadow-black/50 ${
                msg.sender === Sender.USER 
                  ? 'bg-gradient-to-br from-primary to-secondary border border-white/10' 
                  : 'bg-surface border border-white/10'
              }`}>
                {msg.sender === Sender.USER ? <UserIcon size={20} className="text-white" /> : <Sparkles size={20} className="text-accent animate-pulse-slow" />}
              </div>

              {/* Bubble Container */}
              <div className={`flex flex-col gap-2 min-w-0 ${msg.sender === Sender.USER ? 'items-end' : 'items-start'}`}>
                 {/* Image Preview in Bubble */}
                 {msg.image && (
                    <div className="mb-2 rounded-2xl overflow-hidden border border-white/10 max-w-xs shadow-2xl shadow-black/50 transform transition-transform hover:scale-[1.02]">
                        <img src={msg.image} alt="User upload" className="w-full h-auto object-cover" />
                    </div>
                 )}
                 
                 {/* Text Bubble */}
                 <div className={`p-5 rounded-3xl shadow-xl backdrop-blur-md relative ${
                    msg.sender === Sender.USER
                      ? 'bg-primary/90 text-white rounded-tr-none border border-indigo-400/30 bg-gradient-to-br from-primary to-indigo-600'
                      : msg.isError 
                        ? 'bg-red-900/30 border border-red-500/50 text-red-200 rounded-tl-none'
                        : 'glass-panel text-slate-200 rounded-tl-none bg-gradient-to-br from-surface/80 to-slate-900/80'
                  }`}>
                    {msg.sender === Sender.AI ? (
                      <div className="prose prose-invert prose-sm md:prose-base max-w-none 
                        prose-p:leading-relaxed 
                        prose-strong:text-white prose-strong:font-bold prose-strong:bg-white/10 prose-strong:px-1 prose-strong:rounded
                        prose-headings:text-indigo-300 prose-headings:font-bold
                        prose-code:text-accent prose-code:bg-black/30 prose-code:px-1.5 prose-code:py-0.5 prose-code:rounded-md prose-code:font-medium
                        prose-pre:bg-black/40 prose-pre:border prose-pre:border-white/10 prose-pre:rounded-xl prose-pre:shadow-inner
                        prose-a:text-accent prose-a:underline hover:prose-a:text-indigo-300 transition-colors
                        prose-li:marker:text-slate-500
                        prose-blockquote:border-l-4 prose-blockquote:border-primary prose-blockquote:bg-white/5 prose-blockquote:p-4 prose-blockquote:rounded-r-lg">
                        <ReactMarkdown>{msg.text}</ReactMarkdown>
                      </div>
                    ) : (
                      <p className="whitespace-pre-wrap leading-relaxed font-medium">{msg.text}</p>
                    )}
                  </div>

                  {/* Metadata & Actions */}
                  <div className={`flex items-center gap-3 px-2 ${msg.sender === Sender.USER ? 'flex-row-reverse' : 'flex-row'}`}>
                    <span className={`text-[10px] font-medium opacity-50 uppercase tracking-wider ${msg.sender === Sender.USER ? 'text-indigo-200' : 'text-slate-400'}`}>
                        {msg.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                    </span>

                    {/* Action Buttons for AI Messages */}
                    {msg.sender === Sender.AI && !msg.isError && (
                        <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                            <button 
                                onClick={() => handleCopy(msg.text, msg.id)}
                                className="p-1.5 text-slate-500 hover:text-white hover:bg-white/10 rounded-full transition-all"
                                title="Copy"
                            >
                                {copiedId === msg.id ? <Check size={14} className="text-green-400"/> : <Copy size={14} />}
                            </button>
                            <button 
                                onClick={() => handleSpeak(msg.text, msg.id)}
                                className={`p-1.5 rounded-full transition-all ${speakingId === msg.id ? 'text-accent bg-accent/10' : 'text-slate-500 hover:text-white hover:bg-white/10'}`}
                                title="Read Aloud"
                            >
                                <Volume2 size={14} className={speakingId === msg.id ? "animate-pulse" : ""} />
                            </button>
                        </div>
                    )}
                  </div>
              </div>
            </div>
          </div>
        ))}
        
        {/* Loading State */}
        {isLoading && (
          <div className="flex justify-start animate-pulse">
             <div className="flex items-center gap-4">
                <div className="w-10 h-10 rounded-2xl bg-surface border border-white/10 flex items-center justify-center shadow-lg">
                    <Sparkles size={20} className="text-accent" />
                </div>
                <div className="glass-panel px-6 py-4 rounded-3xl rounded-tl-none flex items-center gap-3 border-primary/20">
                    <Loader2 size={18} className="animate-spin text-accent" />
                    <span className="text-sm font-medium text-slate-300 tracking-wide">Deep Chat is thinking...</span>
                </div>
             </div>
          </div>
        )}
        <div ref={messagesEndRef} />
      </div>

      {/* Input Area */}
      <div className="p-4 md:p-6 bg-darker/80 backdrop-blur-xl border-t border-white/5 z-20">
        <div className="max-w-5xl mx-auto relative">
          {/* Image Preview Overlay */}
          {selectedImage && (
              <div className="absolute bottom-full mb-4 left-0 bg-surface/90 backdrop-blur p-2 rounded-2xl border border-white/10 shadow-2xl animate-slide-up flex flex-col gap-1 z-10">
                  <button onClick={() => setSelectedImage(null)} className="self-end p-1.5 bg-black/50 rounded-full text-white hover:bg-red-500 transition-colors">
                      <X size={14} />
                  </button>
                  <img src={selectedImage} alt="Selected" className="w-32 h-32 object-cover rounded-xl" />
              </div>
          )}

          <div className="flex items-end gap-2 bg-surface/50 p-2 rounded-[2rem] border border-white/10 shadow-2xl hover:border-white/20 focus-within:border-primary/50 focus-within:ring-1 focus-within:ring-primary/50 transition-all duration-300">
            <button 
               onClick={() => fileInputRef.current?.click()}
               className="p-3.5 text-slate-400 hover:text-accent hover:bg-white/10 rounded-full transition-all duration-300 flex-shrink-0"
               title="Attach Image"
            >
              <Paperclip size={22} />
            </button>
            <input 
              type="file" 
              ref={fileInputRef} 
              className="hidden" 
              accept="image/*"
              onChange={handleImageSelect} 
            />

            <textarea
              ref={textareaRef}
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === 'Enter' && !e.shiftKey) {
                  e.preventDefault();
                  sendMessage();
                }
              }}
              placeholder="Type a message..."
              className="flex-1 bg-transparent text-white placeholder-slate-400 py-3.5 max-h-32 min-h-[52px] resize-none outline-none overflow-y-auto text-base font-medium scrollbar-thin"
              rows={1}
            />
            
            <div className="flex gap-2 pr-1 pb-1 flex-shrink-0">
               {input.trim() || selectedImage ? (
                  <button 
                    onClick={sendMessage}
                    className="p-3.5 bg-gradient-to-r from-primary to-secondary text-white rounded-full hover:opacity-90 transition-all shadow-lg shadow-primary/25 transform hover:scale-105 active:scale-95"
                  >
                      <Send size={20} />
                  </button>
               ) : (
                  <button 
                      onClick={onStartLive}
                      className="p-3.5 text-slate-400 hover:text-red-400 hover:bg-red-500/10 rounded-full transition-all relative group"
                      title="Start Live Voice Chat"
                  >
                      <Mic size={22} />
                      <span className="absolute top-3 right-3 w-2 h-2 bg-red-500 rounded-full opacity-0 group-hover:opacity-100 animate-ping" />
                  </button>
               )}
            </div>
          </div>
          <p className="text-center text-[10px] text-slate-500 mt-3 font-medium tracking-wide">
            DEEP CHAT AI © 2025 • Created by DIPESH MAHATO KOIRI
          </p>
        </div>
      </div>
    </div>
  );
};