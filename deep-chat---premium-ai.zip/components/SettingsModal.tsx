import React from 'react';
import { AppSettings } from '../types';
import { X, Save, Shield, FileText, User, Mic, Award, Settings, Info } from 'lucide-react';

interface SettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  settings: AppSettings;
  onSave: (newSettings: AppSettings) => void;
}

export const SettingsModal: React.FC<SettingsModalProps> = ({ isOpen, onClose, settings, onSave }) => {
  const [localSettings, setLocalSettings] = React.useState<AppSettings>(settings);
  const [activeTab, setActiveTab] = React.useState<'general' | 'rules'>('general');

  if (!isOpen) return null;

  const handleSave = () => {
    onSave(localSettings);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-[60] flex items-center justify-center bg-black/70 backdrop-blur-sm p-4">
      <div className="bg-surface border border-white/10 w-full max-w-lg rounded-3xl shadow-2xl flex flex-col max-h-[90vh] animate-float overflow-hidden">
        
        {/* Header */}
        <div className="flex justify-between items-center p-6 bg-gradient-to-r from-surface to-white/5 border-b border-white/10">
          <h2 className="text-xl font-bold text-white flex items-center gap-3">
            <Settings size={24} className="text-primary" /> Settings & Info
          </h2>
          <button onClick={onClose} className="p-2 rounded-full bg-white/5 text-slate-400 hover:text-white hover:bg-red-500/20 transition-all">
            <X size={20} />
          </button>
        </div>

        {/* Tabs */}
        <div className="flex border-b border-white/10 bg-black/20">
          <button 
            onClick={() => setActiveTab('general')}
            className={`flex-1 p-4 text-sm font-bold transition-all flex items-center justify-center gap-2 ${activeTab === 'general' ? 'text-white border-b-2 border-primary bg-white/5' : 'text-slate-400 hover:text-slate-200'}`}
          >
            <User size={18} /> Profile & Voice
          </button>
          <button 
            onClick={() => setActiveTab('rules')}
            className={`flex-1 p-4 text-sm font-bold transition-all flex items-center justify-center gap-2 ${activeTab === 'rules' ? 'text-white border-b-2 border-primary bg-white/5' : 'text-slate-400 hover:text-slate-200'}`}
          >
            <Shield size={18} /> Rules & Regulation
          </button>
        </div>

        {/* Content */}
        <div className="p-8 overflow-y-auto flex-1 bg-gradient-to-b from-surface to-darker">
          {activeTab === 'general' ? (
            <div className="space-y-6">
              <div>
                <label className="block text-xs font-bold text-slate-400 uppercase tracking-wider mb-2">Display Name</label>
                <input 
                  type="text" 
                  value={localSettings.userName}
                  onChange={(e) => setLocalSettings({...localSettings, userName: e.target.value})}
                  className="w-full bg-darker border border-slate-700 rounded-xl p-4 text-white focus:ring-2 focus:ring-primary focus:border-transparent outline-none transition-all shadow-inner"
                  placeholder="Enter your name"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-400 uppercase tracking-wider mb-2">System Persona</label>
                <textarea 
                  value={localSettings.systemInstruction}
                  onChange={(e) => setLocalSettings({...localSettings, systemInstruction: e.target.value})}
                  className="w-full bg-darker border border-slate-700 rounded-xl p-4 text-white focus:ring-2 focus:ring-primary focus:border-transparent outline-none transition-all h-32 resize-none shadow-inner leading-relaxed text-sm"
                  placeholder="Define the AI's behavior..."
                />
                <p className="text-xs text-slate-500 mt-2 flex items-center gap-1"><Info size={12}/> Controls how Deep Chat responds to you.</p>
              </div>

               <div>
                <label className="block text-xs font-bold text-slate-400 uppercase tracking-wider mb-2">Voice Persona</label>
                 <div className="relative">
                    <Mic className="absolute left-4 top-1/2 transform -translate-y-1/2 text-slate-400" size={18} />
                    <select
                    value={localSettings.voiceName}
                    onChange={(e) => setLocalSettings({...localSettings, voiceName: e.target.value})}
                    className="w-full bg-darker border border-slate-700 rounded-xl p-4 pl-12 text-white focus:ring-2 focus:ring-primary outline-none appearance-none cursor-pointer hover:bg-slate-900 transition-colors"
                    >
                    <option value="Zephyr">Zephyr (Friendly & Balanced)</option>
                    <option value="Puck">Puck (Energetic & Mischievous)</option>
                    <option value="Kore">Kore (Calm & Soothing)</option>
                    <option value="Fenrir">Fenrir (Deep & Authoritative)</option>
                    <option value="Charon">Charon (Serious & Direct)</option>
                    </select>
                 </div>
              </div>
            </div>
          ) : (
            <div className="space-y-6">
              <div className="bg-white/5 border border-white/10 rounded-2xl p-6">
                 <h3 className="text-lg font-bold text-white mb-4 flex items-center gap-2">
                    <FileText className="text-accent" size={20} /> 
                    Terms of Service
                 </h3>
                 <div className="space-y-3 text-sm text-slate-300 leading-relaxed">
                    <p>
                        <strong className="text-white block mb-1">1. Acceptable Use Policy</strong>
                        Users agree to utilize Deep Chat for lawful purposes only. Generating content that is harmful, hateful, explicit, or violates Google's GenAI Prohibited Use Policy is strictly forbidden.
                    </p>
                    <div className="h-px bg-white/10 my-2"></div>
                    <p>
                        <strong className="text-white block mb-1">2. Privacy & Data</strong>
                        Conversations are processed via Google Gemini API. While we do not store personal data persistently on our servers, avoid sharing sensitive PII (Personally Identifiable Information) like credit cards or passwords.
                    </p>
                    <div className="h-px bg-white/10 my-2"></div>
                    <p>
                        <strong className="text-white block mb-1">3. Liability Disclaimer</strong>
                        Deep Chat is an AI system. Responses may be inaccurate or hallucinated. The developer (DIPESH MAHATO KOIRI) assumes no liability for actions taken based on AI advice.
                    </p>
                 </div>
              </div>

              <div className="bg-gradient-to-r from-indigo-900/20 to-purple-900/20 border border-indigo-500/20 rounded-2xl p-6 flex items-center gap-4">
                 <div className="w-12 h-12 rounded-full bg-indigo-500/20 flex items-center justify-center flex-shrink-0">
                    <Award size={24} className="text-indigo-400" />
                 </div>
                 <div>
                    <h4 className="text-white font-bold">Premium License</h4>
                    <p className="text-xs text-slate-400 mt-1">Developed by <span className="text-indigo-300 font-semibold">DIPESH MAHATO KOIRI</span></p>
                    <p className="text-[10px] text-slate-500 mt-1">v2.0.0 (Deep Chat Edition)</p>
                 </div>
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="p-6 border-t border-white/10 bg-surface">
          <button 
            onClick={handleSave}
            className="w-full bg-gradient-to-r from-primary to-secondary hover:from-indigo-500 hover:to-purple-500 text-white font-bold py-4 px-6 rounded-xl transition-all flex items-center justify-center gap-2 shadow-lg shadow-primary/25 transform hover:scale-[1.02]"
          >
            <Save size={20} /> Save Configuration
          </button>
        </div>
      </div>
    </div>
  );
};