import React from 'react';
import { X, Heart, ShieldCheck, Smartphone, Copy, Check } from 'lucide-react';

interface ContributeModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const ContributeModal: React.FC<ContributeModalProps> = ({ isOpen, onClose }) => {
  const [copied, setCopied] = React.useState(false);

  if (!isOpen) return null;

  const handleCopyNumber = () => {
    navigator.clipboard.writeText('9807291227');
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-[70] flex items-center justify-center bg-black/80 backdrop-blur-md p-4 animate-in fade-in duration-300">
      <div className="bg-white w-full max-w-md rounded-3xl shadow-2xl overflow-hidden flex flex-col animate-slide-up relative">
        
        {/* Close Button */}
        <button 
          onClick={onClose}
          className="absolute top-4 right-4 p-2 bg-black/5 hover:bg-black/10 rounded-full transition-colors z-10 text-slate-600"
        >
          <X size={20} />
        </button>

        {/* Header Gradient */}
        <div className="bg-gradient-to-br from-green-500 to-emerald-700 p-8 text-center relative overflow-hidden">
          <div className="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/cubes.png')] opacity-20"></div>
          <div className="relative z-10">
            <div className="w-16 h-16 bg-white/20 backdrop-blur-sm rounded-full flex items-center justify-center mx-auto mb-4 shadow-lg ring-4 ring-white/10">
               <Heart size={32} className="text-white fill-white animate-pulse-slow" />
            </div>
            <h2 className="text-2xl font-bold text-white">Support Development</h2>
            <p className="text-emerald-100 text-sm mt-2 font-medium">Help keep Deep Chat online and evolving.</p>
          </div>
        </div>

        {/* Content */}
        <div className="p-8 bg-slate-50 flex flex-col items-center">
          
          {/* QR Card Container */}
          <div className="bg-white p-6 rounded-2xl shadow-xl border border-slate-200 w-full max-w-xs transform transition-transform hover:scale-[1.02] duration-300">
             {/* QR Code Placeholder - In a real app, import the image file */}
             <div className="aspect-square bg-slate-900 rounded-lg mb-4 overflow-hidden relative group">
                {/* Placeholder for the QR Image */}
                <div className="absolute inset-0 flex items-center justify-center bg-slate-100">
                    {/* 
                        NOTE: Replace the src below with your actual QR code image path.
                        If you have the image in your project, import it. 
                    */}
                    <img 
                        src="https://api.qrserver.com/v1/create-qr-code/?size=300x300&data=eSewa-Transfer-9807291227" 
                        alt="Payment QR Code" 
                        className="w-full h-full object-cover mix-blend-multiply opacity-90"
                    />
                    {/* Overlay to simulate scanning feeling */}
                    <div className="absolute top-0 left-0 w-full h-1 bg-green-500/50 shadow-[0_0_15px_rgba(34,197,94,0.8)] animate-[scan_2s_ease-in-out_infinite]"></div>
                </div>
             </div>

             {/* Payment Details */}
             <div className="text-center space-y-3">
                <div className="flex items-center justify-center gap-2 mb-2">
                    {/* eSewa Logo Simulation */}
                    <div className="flex items-center font-bold text-xl tracking-tight">
                        <span className="w-6 h-6 bg-green-500 rounded-full flex items-center justify-center text-white mr-1 text-sm italic">e</span>
                        <span className="text-slate-800">Sewa</span>
                    </div>
                </div>

                <div>
                    <h3 className="font-bold text-slate-800 text-lg">Dipesh Mahato Koiri</h3>
                    <div className="flex items-center justify-center gap-2 mt-1">
                        <span className="font-mono text-slate-600 text-lg tracking-wide">9807291227</span>
                        <button 
                            onClick={handleCopyNumber}
                            className="p-1.5 text-slate-400 hover:text-green-600 hover:bg-green-50 rounded-md transition-all"
                            title="Copy Number"
                        >
                            {copied ? <Check size={16} className="text-green-600" /> : <Copy size={16} />}
                        </button>
                    </div>
                </div>
             </div>
          </div>

          {/* CTA */}
          <div className="mt-8 w-full space-y-3">
            <div className="flex items-center justify-between bg-white p-4 rounded-xl border border-slate-200 shadow-sm">
                <div className="flex items-center gap-3">
                    <div className="p-2 bg-amber-100 text-amber-600 rounded-lg">
                        <Smartphone size={20} />
                    </div>
                    <div>
                        <p className="text-xs text-slate-500 font-bold uppercase">Contribution Amount</p>
                        <p className="text-slate-800 font-bold">Rs. 1000</p>
                    </div>
                </div>
                <span className="px-3 py-1 bg-green-100 text-green-700 text-xs font-bold rounded-full">Preferred</span>
            </div>

            <div className="flex items-start gap-3 p-3 bg-blue-50 rounded-xl">
                <ShieldCheck size={18} className="text-blue-600 flex-shrink-0 mt-0.5" />
                <p className="text-xs text-blue-700 leading-relaxed">
                    Your contribution directly supports server costs, API fees for Gemini Advanced, and future development of Deep Chat features.
                </p>
            </div>
          </div>

        </div>
      </div>
      
      <style>{`
        @keyframes scan {
            0% { top: 0%; opacity: 0; }
            10% { opacity: 1; }
            90% { opacity: 1; }
            100% { top: 100%; opacity: 0; }
        }
      `}</style>
    </div>
  );
};