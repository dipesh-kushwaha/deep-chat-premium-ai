import { GoogleGenAI, Type } from "@google/genai";
import { Message, Sender } from "../types";

const API_KEY = process.env.API_KEY || '';

const ai = new GoogleGenAI({ apiKey: API_KEY });

export const generateTextResponse = async (
  history: Message[], 
  newMessage: string, 
  systemInstruction: string,
  image?: string
): Promise<string> => {
  try {
    // Format history for the API (simplified for this demo, ideally we map correctly to Content objects)
    // We will just send the last prompt + context for this stateless wrapper, 
    // or strictly use the new chat interface.
    
    const modelName = 'gemini-2.5-flash'; 
    
    const chat = ai.chats.create({
      model: modelName,
      config: {
        systemInstruction: systemInstruction,
      }
    });

    // If image is present, we need to send it.
    // Chat history reconstruction is complex here without maintaining the full Chat object state 
    // in the React component. For this demo, we will treat it as a single turn or basic history
    // if we were using the full history array to reconstruct.
    
    // Ideally:
    // 1. Pass previous history to chat.
    // 2. Send new message.
    
    // For this "Premium App" feel, we'll just send the current message for simplicity 
    // to avoid token limit issues in a long history demo, 
    // but in a real app, you'd iterate `history` and add to `history` prop of chat.create.
    
    // Construct current message part
    let contents: any = [{ text: newMessage }];
    
    if (image) {
        // Image is expected to be a data URL: data:image/png;base64,....
        const base64Data = image.split(',')[1];
        const mimeType = image.split(':')[1].split(';')[0];
        
        contents = [
            {
                inlineData: {
                    mimeType: mimeType,
                    data: base64Data
                }
            },
            { text: newMessage }
        ];
    }

    const response = await chat.sendMessage({
        message: {
            role: 'user',
            parts: contents
        }
    });

    return response.text || "I couldn't generate a response.";

  } catch (error) {
    console.error("Gemini API Error:", error);
    throw error;
  }
};

export const getClient = () => ai;